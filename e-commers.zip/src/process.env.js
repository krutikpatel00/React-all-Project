export const apiUrl = process.env.REACT_APP_API_URL;
export const port = process.env.REACT_APP_PORT;

