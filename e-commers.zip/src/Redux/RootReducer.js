import { combineReducers } from 'redux';
import CardReducer from './Reducer/CardReducer';


const RootReducer = combineReducers({
      CardReducer
})

export default RootReducer