import React from 'react'
import Col from 'react-bootstrap/esm/Col'
import Row from 'react-bootstrap/esm/Row'
import Form from 'react-bootstrap/Form';
import { Occupation, Country } from '../data/DataInfromtion'
import { NavLink } from 'react-bootstrap'
const PersonalDetails = ({ setToggleBtn, GetInputValue, ErrorMessageData, OnePersonData }) => {
     return (
          <div>
               <Row>
                    <Col className="col-4">
                         <Form.Control
                              type="text"
                              className='mt-4'
                              placeholder='First Name'
                              aria-describedby="inputFirstName"
                              name='firstName'
                              value={OnePersonData.firstName ? OnePersonData.firstName : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.firstNameError ? ErrorMessageData.firstNameError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-4">
                         <Form.Control
                              type="text"
                              className='mt-4'
                              placeholder='Middle Name [Optional]'
                              aria-describedby="inputMiddleName"
                              name='middleName'
                              value={OnePersonData.middleName ? OnePersonData.middleName : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.middleNameError ? ErrorMessageData.middleNameError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-4">
                         <Form.Control
                              type="text"
                              className='mt-4'
                              placeholder='Last Name [Optional]'
                              aria-describedby="inputLastName"
                              name='lastName'
                              value={OnePersonData.lastName ? OnePersonData.lastName : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.lastNameError ? ErrorMessageData.lastNameError : ''}</p>
                         </div>
                    </Col>
               </Row>
               <p>Info!Please provide your exact name as per Aadhaar to avail Aadhaar based benefits on IRCTC eTicketing website.</p>
               <Row className="align-items-center">
                    <Col className="col-6">
                         <Form.Select aria-label="Default select example3" onChange={(e) => GetInputValue(e)} name='occupation' defaultValue={OnePersonData.occupatio ? OnePersonData.occupation : ''} >
                              <option disabled value={''}>Select Occupation</option>
                              {
                                   Occupation.map((items, pos) => {
                                        return (
                                             <option key={pos} value={items}>{items}</option>
                                        )
                                   })
                              }
                         </Form.Select>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.occupationError ? ErrorMessageData.occupationError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <Form.Control
                              type="date"
                              id="inputDate"
                              name='date'
                              value={OnePersonData.date ? OnePersonData.date : ''}
                              aria-describedby="inputDate"
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.dateError ? ErrorMessageData.dateError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <div className="d-flex justify-content-around mt-4">
                              <Form.Check
                                   inline
                                   label="Married"
                                   type='radio'
                                   name='maritalStatus'
                                   value="Married"
                                   onChange={(e) => GetInputValue(e)}

                              />
                              <Form.Check
                                   inline
                                   label="Unmarried"
                                   type='radio'
                                   name='maritalStatus'
                                   value="Unmarried"
                                   onChange={(e) => GetInputValue(e)}

                              />

                         </div>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.maritalStatusError ? ErrorMessageData.maritalStatusError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <Form.Select aria-label="Default select example" defaultValue={OnePersonData.country ? OnePersonData.country : ''} className='my-2' name='country' onChange={(e) => GetInputValue(e)}>
                              <option disabled value={''} >Select a Country</option>
                              {
                                   Country.map((items, pos) => {
                                        return (
                                             <option key={pos} value={items}>{items}</option>
                                        )
                                   })
                              }

                         </Form.Select>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.countryError ? ErrorMessageData.countryError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <div className="container-gender">
                              <input
                                   type="radio"
                                   id="male"
                                   value="male"
                                   name='gender'

                                   onChange={(e) => GetInputValue(e)}
                              />
                              <label htmlFor="male">Male</label>

                              <input
                                   type="radio"
                                   id="female"
                                   value="female"
                                   name='gender'
                                   onChange={(e) => GetInputValue(e)}

                              />
                              <label htmlFor="female">Female</label>
                              <input
                                   type="radio"
                                   id="transgender"
                                   value="transgender"
                                   name='gender'
                                   onChange={(e) => GetInputValue(e)}

                              />
                              <label htmlFor="transgender">Transgender</label>
                         </div>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.genderError ? ErrorMessageData.genderError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <Form.Control
                              className='my-2'
                              type="text"
                              aria-describedby="inputEmail"
                              placeholder='Enter Email'
                              name='email'
                              value={OnePersonData.email ? OnePersonData.email : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.emailError ? ErrorMessageData.emailError : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <Form.Control
                              type="text"
                              className='my-2'
                              aria-describedby="inputphone"
                              placeholder='Phone Number'
                              name='phone1'
                              value={OnePersonData.phone1 ? OnePersonData.phone1 : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.phone1Error ? ErrorMessageData.phone1Error : ''}</p>
                         </div>
                    </Col>
                    <Col className="col-6">
                         <Form.Select aria-label="Default select example" name='nationality' onChange={(e) => GetInputValue(e)} defaultValue={OnePersonData.nationality ? OnePersonData.nationality : ''}>
                              <option disabled value={''}>Select a Nationality</option>
                              {
                                   Country.map((items, pos) => {
                                        return (
                                             <option key={pos} value={items}>{items}</option>
                                        )
                                   })
                              }
                         </Form.Select>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.nationalityError ? ErrorMessageData.nationalityError : ''}</p>
                         </div>
                    </Col>
               </Row>
               <div className='d-flex justify-content-between pt-5'>
                    <a href='javscript:void' className='py-2 px-5  bg-black text-white  rounded-3' eventKey="basic" onClick={() => setToggleBtn('basic')} >Back</a>
                    <NavLink className='bg-black text-white py-2 px-5 border-0 rounded-3' eventKey="address" onClick={() => setToggleBtn('address')}>Continue</NavLink>
               </div>
          </div>
     )
}

export default PersonalDetails