import React from 'react'
import { LuRefreshCcw } from "react-icons/lu";
import { Row, Col, Form } from 'react-bootstrap'
import { Link } from 'react-router-dom'
const Address = ({ setToggleBtn, GetInputValue, ErrorMessageData, OnePersonData, checkboxStates, captchaChallenge, regenerateCaptcha }) => {
     return (
          <div>
               <Row className='align-items-center'>
                    <Col className='col-6'>
                         <Form.Control
                              type=""
                              className='mt-2'
                              placeholder='Flat/Door/Block No.'
                              aria-describedby="inputBlockNO"
                              name='blockNo'
                              value={OnePersonData.blockNo ? OnePersonData.blockNo : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.blockNoError ? ErrorMessageData.blockNoError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='Street/Lane (Optional)'
                              aria-describedby="inputStreet"
                              name='Street'
                              value={OnePersonData.Street ? OnePersonData.Street : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.StreetError ? ErrorMessageData.StreetError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='Area/Location (Optional)'
                              aria-describedby="inputLocation"
                              name='Location'
                              value={OnePersonData.Location ? OnePersonData.Location : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.LocationError ? ErrorMessageData.LocationError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='Pin code'
                              aria-describedby="inputPinCode"
                              name='pinCode'
                              value={OnePersonData.pinCode ? OnePersonData.pinCode : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.pinCodeError ? ErrorMessageData.pinCodeError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='City / Town'
                              aria-describedby="inputCityTown"
                              name='city'
                              value={OnePersonData.city ? OnePersonData.city : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.cityError ? ErrorMessageData.cityError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='State'
                              aria-describedby="inputState"
                              name='State'
                              value={OnePersonData.State ? OnePersonData.State : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.StateError ? ErrorMessageData.StateError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='Post Office'
                              aria-describedby="inputPostOffice"
                              name='postOffice'
                              value={OnePersonData.postOffice ? OnePersonData.postOffice : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.postOfficeError ? ErrorMessageData.postOfficeError : ''}</p>
                         </div>
                    </Col>
                    <Col className='col-6'>
                         <Form.Control
                              type="text"
                              className='mt-2'
                              placeholder='Phone Number'
                              aria-describedby="inputPhonenumber"
                              name='phone2'
                              value={OnePersonData.phone2 ? OnePersonData.phone2 : ''}
                              onChange={(e) => GetInputValue(e)}
                         />
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.phone2Error ? ErrorMessageData.phone2Error : ''}</p>
                         </div>
                    </Col>

                    <Col className='col-12'>
                         <div className='d-flex justify-content-center align-items-center'>
                              <Form.Check
                                   type="checkbox"
                                   aria-describedby="inputcheckboxoptions"
                                   onChange={(e) => GetInputValue(e)}
                                   name='OptionalSmsPhoneNumber'
                                   value={checkboxStates.OptionalSmsPhoneNumber ? checkboxStates.OptionalSmsPhoneNumber : ''}
                              />
                              <p className='mb-0 ms-2'>Please inform me about IRCTC Co-branded credit card through Phone/Email/SMS (Optional)</p>
                         </div>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.OptionalSmsPhoneNumberError ? ErrorMessageData.OptionalSmsPhoneNumberError : ''}</p>
                         </div>
                         <span className='py-3'>Enjoy the railway ticket booking with 1% PG transaction charges waiver with IRCTC SBI/BOB/HDFC cards and also you can book ticket using earned loyalty reward points
                         </span>
                    </Col>
                    <Col className='col-8'>
                         <div className='border border-1 rounded-3'>
                              <div className='d-flex flex-column p-4'>
                                   <div className='d-flex justify-content-between align-items-center'>
                                        <span className='text-center  mb-2 fs-5'>{captchaChallenge}</span>
                                        <LuRefreshCcw onClick={regenerateCaptcha} className='fs-4 inline-block' />
                                   </div>
                                   <Form.Control
                                        type="text"
                                        className='mt-2 w-100'
                                        aria-describedby="inputcaptcharcode"
                                        placeholder='captcha code'
                                        name='captcha'
                                        value={OnePersonData.captcha ? OnePersonData.captcha : ''}
                                        onChange={(e) => GetInputValue(e)}

                                   />
                                   <div className='meassage-error'>
                                        <p>{ErrorMessageData.captchaError ? ErrorMessageData.captchaError : ''}</p>
                                   </div>
                              </div>

                         </div>
                    </Col>
                    <Col className='col-12'>
                         <div className='d-flex align-items-center mt-4'>
                              <Form.Check
                                   type="checkbox"
                                   className='me-2'
                                   aria-describedby="inputcheckboxoptionsagreement"
                                   name='agreemetes'
                                   value={checkboxStates.agreemetes ? checkboxStates.agreemetes : ''}
                                   onChange={(e) => GetInputValue(e)}
                              />
                              <p className='mb-0 ms-2'>I have read and agree with the Terms and Conditions and also agree to receive promotional emails/SMS/WhatsApp/Alerts/offers/announcements from IRCTC & associated partners.    </p>

                         </div>
                         <div className='meassage-error'>
                              <p>{ErrorMessageData.agreemetesError ? ErrorMessageData.agreemetesError : ''}</p>
                         </div>
                    </Col>
               </Row>
               <div className='d-flex justify-content-between pt-5'>
                    <a href='javscript:void' className='py-2 px-5 rounded-3 bg-black text-white ' eventKey="personal" onClick={() => setToggleBtn('personal')} >Back</a>

                    <button type='submit' className='py-2 px-5 border-0 rounded-3 bg-success text-white fw-bolder'>REGISTER</button>
               </div>
               <div className='meassage-error'>
                    <p>{ErrorMessageData.ErrorFormNotCamplte ? ErrorMessageData.ErrorFormNotCamplte : ''}</p>
               </div>
          </div>
     )
}

export default Address