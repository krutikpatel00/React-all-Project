import React, { useState, useEffect } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import PersonalDetails from "./PersonalDetails";
import BasicDetails from "./BasicDetails";
import Address from "./Address";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from 'react-bootstrap/Form';
import { useNavigate } from "react-router-dom";

const generateRandomString = (length) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

const Registration = () => {
  const navigation = useNavigate()
  const [ToggleBtn, setToggleBtn] = useState('basic')
  const [OnePersonData, setOnePersonData] = useState({})
  const [checkboxStates, setcheckboxStates] = useState({ OptionalSmsPhoneNumber: true, agreemetes: true });
  const [allUsersData, setAllUsersData] = useState([])
  const [ErrorMessageData, setErrorMessageData] = useState({})

  const captchaLength = 6;
  const [captchaChallenge, setCaptchaChallenge] = useState(generateRandomString(captchaLength));
  const [userInput, setUserInput] = useState('');

  const regenerateCaptcha = () => {
    setCaptchaChallenge(generateRandomString(captchaLength));
    setUserInput('');

  };

  useEffect(() => {
    let data = JSON.parse(localStorage.getItem('UserData'))
    if (data === null) {
      setAllUsersData([])
    } else {
      setAllUsersData(data)
    }


  }, [setAllUsersData])




  const GetInputValue = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    checkboxStates[name] = !(e.target.checked);
    const id = Math.floor(Math.random() * 10000)

    const phoneno = /^\d{10}$/;
    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    const decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    var pat1 = /^\d{6}$/;
    var regexPattern = /^[a-zA-Z0-9]+$/;

    if (name === 'username') {
      if (value === '') {
        console.log(value);
        setErrorMessageData({ ...ErrorMessageData, UserNameError: 'User Name is required.' })
      }
      else if (!value.match(regexPattern)) {
        setErrorMessageData({ ...ErrorMessageData, UserNameError: 'User ID is invalid.Between 3 to 35 character.Only letter and number are allowed.' })
      }
      else if (value !== '') {
        allUsersData.map((items, pos) => {
          return items.username === value ? setErrorMessageData({ ...ErrorMessageData, error: `User Name [ ${value} ] Not Available` }) : setErrorMessageData({ ...ErrorMessageData, UserNameError: '' });
        })
      }
      else {
        setErrorMessageData({ ...ErrorMessageData, UserNameError: '' })
      }
    }
    else if (name === 'passowrd') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, PasswordError: 'Password is required.' });
      } else if (!(value.match(decimal))) {
        setErrorMessageData({ ...ErrorMessageData, PasswordError: 'Password is invalid.Min 8 character & Max 15 character. Password must contain at least one small & one capital alphabet and numeric digit' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, PasswordError: '' });
      }
    }
    else if (name === 'confirmPassword') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: 'Confirm password is required.' });
      } else if (!(value.match(decimal))) {
        setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: 'Password is invalid.Min 8 character & Max 15 character. Password must contain at least one small & one capital alphabet and numeric digit' })
      } else if (value !== OnePersonData.passowrd) {
        setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: 'Password and Confirm password not Matched' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: '' });
      }
    }
    else if (name === 'language') {
      if (value === 'Preferred Language') {
        setErrorMessageData({ ...ErrorMessageData, LanguageError: 'Preferred Language is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, LanguageError: '' })
      }
    }
    else if (name === 'question') {
      if (value === 'Security Question') {
        setErrorMessageData({ ...ErrorMessageData, questionError: 'Preferred Question is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, questionError: '' })
      }
    }
    else if (name === 'answer') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, answerError: 'Security Answer is Required.' })
      } else if (value.length < 3 || value.length > 20) {
        setErrorMessageData({ ...ErrorMessageData, answerError: 'Security Answer is invalid.Between 3 to 20 character.Only letter and number are allowed.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, answerError: '' })
      }
    }
    else if (name === 'firstName') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, firstNameError: 'First Name is required..' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, firstNameError: '' })
      }
    }
    else if (name === 'middleName') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, middleNameError: 'First middleName is required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, middleNameError: '' })
      }
    }
    else if (name === 'lastName') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, lastNameError: 'First lastName is required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, lastNameError: '' })
      }
    }
    else if (name === 'occupation') {
      if (value === 'Select Occupation') {
        setErrorMessageData({ ...ErrorMessageData, occupationError: 'Occupation is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, occupationError: '' })
      }
    }
    else if (name === 'date') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, dateError: 'Select Date Of Birth.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, dateError: '' })
      }
    }
    else if (name === 'maritalStatus') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, maritalStatusError: 'maritalStatus is Required.' })
      }
      else {
        setErrorMessageData({ ...ErrorMessageData, maritalStatusError: '' })
      }
    }
    else if (name === 'gender') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, genderError: 'gender is Required.' })
      }
      else {
        setErrorMessageData({ ...ErrorMessageData, genderError: '' })
      }

    }
    else if (name === 'country') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, countryError: 'country is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, countryError: '' })
      }
    }
    else if (name === 'email') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, emailError: 'Email is required' })
      } else if (!(value.match(mailformat))) {
        setErrorMessageData({ ...ErrorMessageData, emailError: 'Enter valid Email.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, emailError: '' })
      }
    }
    else if (name === 'phone1') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, phone1Error: 'Mobile No is required..' })
      }
      if (!(value.match(phoneno))) {
        setErrorMessageData({ ...ErrorMessageData, phone1Error: 'Mobile No is invalid. Only numeric character entry is allowed.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, phone1Error: '' })
      }
    }
    else if (name === 'nationality') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, nationalityError: 'nationality is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, nationalityError: '' })
      }
    }
    else if (name === 'blockNo') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, blockNoError: 'blockNo is Required.' })
      } else if (value.length < 3) {
        setErrorMessageData({ ...ErrorMessageData, blockNoError: 'Flat / House No. / Floor / Building is required.Invalid Flat / House No. / Floor / Building .Only letter, number ,spaces and characters " , - _: ) (/ " are allowed between 3 to 225 character.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, blockNoError: '' })
      }
    }
    else if (name === 'Street') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, StreetError: 'Street is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, StreetError: '' })
      }
    }
    else if (name === 'Location') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, LocationError: 'Location is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, LocationError: '' })
      }
    }
    else if (name === 'pinCode') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, pinCodeError: 'pinCode is Required.' })
      } else if (!value.match(pat1)) {
        setErrorMessageData({ ...ErrorMessageData, pinCodeError: 'only 6 digite nubmer in pincode.' })
      }
      else {
        setErrorMessageData({ ...ErrorMessageData, pinCodeError: '' })
      }
    }
    else if (name === 'city') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, cityError: 'city is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, cityError: '' })
      }
    } else if (name === 'State') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, StateError: 'state is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, StateError: '' })
      }
    } else if (name === 'postOffice') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, postOfficeError: 'postOffice is Required.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, postOfficeError: '' })
      }
    } else if (name === 'phone2') {
      if (value === '') {
        setErrorMessageData({ ...ErrorMessageData, phone2Error: 'Mobile No is required..' })
      }
      if (!(value.match(phoneno))) {
        setErrorMessageData({ ...ErrorMessageData, phone2Error: 'Mobile No is invalid. Only numeric character entry is allowed.' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, phone2Error: '' })
      }
    } else if (name === 'OptionalSmsPhoneNumber') {
      if (!(e.target.checked)) {
        setErrorMessageData({ ...ErrorMessageData, OptionalSmsPhoneNumberError: 'select checkbox is required' })

      } else {
        setErrorMessageData({ ...ErrorMessageData, OptionalSmsPhoneNumberError: '' })
      }
    }
    else if (name === 'agreemetes') {
      if (!(e.target.checked)) {
        setErrorMessageData({ ...ErrorMessageData, agreemetesError: 'select checkbox is required' })

      } else {
        setErrorMessageData({ ...ErrorMessageData, agreemetesError: '' })
      }
    }
    else if (name === 'captcha') {
      if ((!value === checkboxStates)) {
        setErrorMessageData({ ...ErrorMessageData, captchaError: 'captchar is Required ' })
      } else {
        setErrorMessageData({ ...ErrorMessageData, captchaError: '' })
      }
    }
    const data = { ...OnePersonData, [name]: value, id: id }
    setOnePersonData(data)
  }

  const DataSubmit = (e) => {
    e.preventDefault()
    const phoneno = /^\d{10}$/;
    const phoneno1 = /^\d{10}$/;
    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    const decimal = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    var pat1 = /^\d{6}$/;
    var regexPattern = /^[a-zA-Z0-9]+$/;

    if (OnePersonData.username === undefined) {
      setErrorMessageData({ ...ErrorMessageData, UserNameError: 'User Name is required.' })
    }
    else if (OnePersonData.username.length < 3 || OnePersonData.username.length > 35) {
      setErrorMessageData({ ...ErrorMessageData, UserNameError: 'User ID is invalid.Between 3 to 35 character.Only letter and number are allowed.' })
    }
    else if (!OnePersonData.username.match(regexPattern)) {
      setErrorMessageData({ ...ErrorMessageData, UserNameError: 'User ID is invalid.Between 3 to 35 character.Only letter and number are allowed.' })
    }
    else if (OnePersonData.username === allUsersData.map((items) => items.username)) {
      setErrorMessageData({ ...ErrorMessageData, error: `User Name [ ${OnePersonData.username} ] Not Available` })
    }
    else if (OnePersonData.passowrd === undefined) {
      setErrorMessageData({ ...ErrorMessageData, PasswordError: 'Password is required.' });
    }
    else if (!(OnePersonData.passowrd.match(decimal))) {
      setErrorMessageData({ ...ErrorMessageData, PasswordError: 'Password is invalid.Min 8 character & Max 15 character. Password must contain at least one small & one capital alphabet and numeric digit' })
    }
    else if (OnePersonData.confirmPassword === undefined) {
      setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: 'Confirm password is required.' });
    }
    else if (OnePersonData.confirmPassword !== OnePersonData.passowrd) {
      setErrorMessageData({ ...ErrorMessageData, confirmPasswordError: 'Password and Confirm password not Matched' })
    }
    else if (OnePersonData.language === undefined) {
      setErrorMessageData({ ...ErrorMessageData, LanguageError: 'Preferred Language is Required.' })
    }
    else if (OnePersonData.question === undefined) {
      setErrorMessageData({ ...ErrorMessageData, questionError: 'Preferred Question is Required.' })
    }
    else if (OnePersonData.answer === undefined) {
      setErrorMessageData({ ...ErrorMessageData, answerError: 'Security Answer is Required.' })
    }
    else if (OnePersonData.answer.length < 3 || OnePersonData.answer.length > 20) {
      setErrorMessageData({ ...ErrorMessageData, answerError: 'Security Answer is invalid.Between 3 to 20 character.Only letter and number are allowed.' })
    }
    else if (OnePersonData.firstName === undefined) {
      setErrorMessageData({ ...ErrorMessageData, firstNameError: 'First Name is required..' })
    }
    else if (OnePersonData.middleName === undefined) {
      setErrorMessageData({ ...ErrorMessageData, middleNameError: 'First middleName is required.' })
    }
    else if (OnePersonData.lastName === undefined) {
      setErrorMessageData({ ...ErrorMessageData, lastNameError: 'First lastName is required.' })
    }
    else if (OnePersonData.occupation === undefined) {
      setErrorMessageData({ ...ErrorMessageData, occupationError: 'Occupation is Required.' })
    }
    else if (OnePersonData.date === undefined) {
      setErrorMessageData({ ...ErrorMessageData, dateError: 'Select Date Of Birth.' })
    }
    else if (OnePersonData.maritalStatus === undefined) {
      setErrorMessageData({ ...ErrorMessageData, maritalStatusError: 'maritalStatus is Required.' })
    }

    else if (OnePersonData.gender === undefined) {
      setErrorMessageData({ ...ErrorMessageData, genderError: 'gender is Required.' })
    }
    else if (OnePersonData.country === undefined) {
      setErrorMessageData({ ...ErrorMessageData, countryError: 'country is Required.' })
    }
    else if (OnePersonData.email === undefined) {
      setErrorMessageData({ ...ErrorMessageData, emailError: 'Email is required' })
    }
    else if (!(OnePersonData.email.match(mailformat))) {
      setErrorMessageData({ ...ErrorMessageData, emailError: 'Enter valid Email.' })
    }
    else if (OnePersonData.phone1 === undefined) {
      setErrorMessageData({ ...ErrorMessageData, phone1Error: 'Mobile No is required..' })
    }
    else if (!(OnePersonData.phone1.match(phoneno1))) {
      setErrorMessageData({ ...ErrorMessageData, phone1Error: 'Mobile No is invalid. Only numeric character entry is allowed.' })
    }
    else if (OnePersonData.nationality === undefined) {
      setErrorMessageData({ ...ErrorMessageData, nationalityError: 'nationality is Required.' })
    }
    else if (OnePersonData.blockNo === undefined) {
      setErrorMessageData({ ...ErrorMessageData, blockNoError: 'blockNo is Required.' })
    }
    else if (OnePersonData.blockNo.length < 3) {
      setErrorMessageData({ ...ErrorMessageData, blockNoError: 'Flat / House No. / Floor / Building is required.Invalid Flat / House No. / Floor / Building .Only letter, number ,spaces and characters " , - _: ) (/ " are allowed between 3 to 225 character.' })
    }
    else if (OnePersonData.Street === undefined) {
      setErrorMessageData({ ...ErrorMessageData, StreetError: 'Street is Required.' })
    }
    else if (OnePersonData.Location === undefined) {
      setErrorMessageData({ ...ErrorMessageData, LocationError: 'Location is Required.' })
    }
    else if (OnePersonData.pinCode === undefined) {
      setErrorMessageData({ ...ErrorMessageData, pinCodeError: 'pinCode is Required.' })
    }
    else if (!OnePersonData.pinCode.match(pat1)) {
      setErrorMessageData({ ...ErrorMessageData, pinCodeError: 'only 6 digite nubmer in pincode.' })
    }
    else if (OnePersonData.city === undefined) {
      setErrorMessageData({ ...ErrorMessageData, cityError: 'city is Required.' })
    }
    else if (OnePersonData.State === undefined) {
      setErrorMessageData({ ...ErrorMessageData, StateError: 'state is Required.' })
    }
    else if (OnePersonData.postOffice === undefined) {
      setErrorMessageData({ ...ErrorMessageData, postOfficeError: 'postOffice is Required.' })
    }
    else if (OnePersonData.phone2 === undefined) {
      setErrorMessageData({ ...ErrorMessageData, phone2Error: 'Mobile No is required.' })
    }
    else if (!(OnePersonData.phone2.match(phoneno))) {
      setErrorMessageData({ ...ErrorMessageData, phone2Error: 'Mobile No is invalid. Only numeric character entry is allowed.' })
    } else if (OnePersonData.phone2 === undefined) {
      setErrorMessageData({ ...ErrorMessageData, phone2Error: 'Mobile No is invalid. Only numeric character entry is allowed.' })
    }
    else if (!(OnePersonData.agreemetes)) {
      setErrorMessageData({ ...ErrorMessageData, agreemetesError: 'this checkbox is required.' })
    }
    else if (!(OnePersonData.OptionalSmsPhoneNumber)) {
      setErrorMessageData({ ...ErrorMessageData, OptionalSmsPhoneNumberError: 'this checkbox is required' })
    }
    else if (OnePersonData.captcha === undefined) {
      setErrorMessageData({ ...ErrorMessageData, captchaError: 'captchar is Required ' })
    }
    else if (!(OnePersonData.captcha === captchaChallenge)) {
      setErrorMessageData({ ...ErrorMessageData, captchaError: 'captchar is not match' })
    }
    else {

      let data = [...allUsersData, OnePersonData]
      setAllUsersData(data)
      navigation('/view')
      localStorage.setItem('UserData', JSON.stringify(data))

      setOnePersonData({})
    }

  }


  return (
    <div className="registration-from rounded-4 my-5">

      <Container>
        <div className="d-flex justify-content-between align-items-center pb-5">
          <h2>Create Your account</h2>
          <a href="link">SIGN IN</a>
        </div>
        <Row>
          <Col className="col-12">
            <Form method="post" onSubmit={(e) => DataSubmit(e)}>
              <Tabs
                onSelect={(key) => setToggleBtn(key)}
                activeKey={ToggleBtn}
                transition={true}
                id="noanim-tab-example"
                className="mb-4"
              >
                <Tab eventKey="basic" title="Basic Details" >
                  <BasicDetails GetInputValue={GetInputValue} OnePersonData={OnePersonData} setToggleBtn={setToggleBtn} ErrorMessageData={ErrorMessageData} />
                </Tab>
                <Tab eventKey="personal" title="Personal Details">
                  <PersonalDetails OnePersonData={OnePersonData} setToggleBtn={setToggleBtn} GetInputValue={GetInputValue} ErrorMessageData={ErrorMessageData} />
                </Tab>
                <Tab eventKey="address" title="Address">
                  <Address DataSubmit={DataSubmit} setToggleBtn={setToggleBtn} GetInputValue={GetInputValue} checkboxStates={checkboxStates} ErrorMessageData={ErrorMessageData} OnePersonData={OnePersonData} captchaChallenge={captchaChallenge} userInput={userInput} regenerateCaptcha={regenerateCaptcha} />
                </Tab>
              </Tabs>
            </Form>
          </Col>
        </Row>

      </Container>
    </div>
  );
};

export default Registration;
