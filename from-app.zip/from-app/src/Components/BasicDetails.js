import React from 'react'
import Col from 'react-bootstrap/esm/Col'
import Row from 'react-bootstrap/esm/Row'
import { Form, NavLink } from 'react-bootstrap'
import { Language, Qus } from '../data/DataInfromtion'
const BasicDetails = ({ GetInputValue, setToggleBtn, ErrorMessageData, OnePersonData }) => {
  return (
    <>
      <div>
        < Form>
          <div>
            <h4>GARBAGE/JUNK VALUES IN PROFILE MAY LEAD TO DEACTIVATION</h4>
            <p>
              Please use a valid E-Mail ID and mobile number in registration.</p>
          </div>
          <Row className='flex-col'>
            <Col className='col-12'>
              <div>
                <Form.Control
                  type="text"
                  className='mt-4'
                  name="username"
                  placeholder='User Name'
                  aria-describedby="inputUsername"
                  value={OnePersonData.username ? OnePersonData.username : ''}
                  onChange={(e) => GetInputValue(e)}
                />
                <div className='meassage-error'>
                  <p>{ErrorMessageData.UserNameError ? ErrorMessageData.UserNameError : ''}</p>
                </div>
              </div>
              <Form.Control
                type="password"
                name="passowrd"
                className='mt-4'
                placeholder='Password'
                value={OnePersonData.passowrd ? OnePersonData.passowrd : ''}
                aria-describedby="inputPassoword"
                onChange={(e) => GetInputValue(e)}
              />
              <div className='meassage-error'>
                <p>{ErrorMessageData.PasswordError ? ErrorMessageData.PasswordError : ''}</p>
              </div>
              <Form.Control
                type="password"
                name="confirmPassword"
                className='mt-4'
                placeholder='Confirm Password'
                value={OnePersonData.confirmPassword ? OnePersonData.confirmPassword : ''}
                aria-describedby="inputConfirmPassword"
                onChange={(e) => GetInputValue(e)}
              />
              <div className='meassage-error'>
                <p>{ErrorMessageData.confirmPasswordError ? ErrorMessageData.confirmPasswordError : ''}</p>
              </div>
              <Form.Select aria-label="Default select example1" name="language" className='mt-4' onChange={(e) => GetInputValue(e)} defaultValue={OnePersonData.language ? OnePersonData.language : 'Preferred Language'}>
                <option disabled value="Preferred Language" unselectable=''>Preferred Language</option>
                {
                  Language.map((language, i) => {
                    return (
                      <option key={i} value={language}>{language}</option>
                    )
                  })
                }
              </Form.Select>
              <div className='meassage-error'>
                <p>{ErrorMessageData.LanguageError ? ErrorMessageData.LanguageError : ''}</p>
              </div>
              <Form.Select aria-label="Default select example2" name="question" className='mt-4' defaultValue={OnePersonData.question ? OnePersonData.question : 'Security Question'} onChange={(e) => GetInputValue(e)}>
                <option disabled value={'Security Question'}>Security Question</option>
                {
                  Qus.map((qus, i) => {
                    return (
                      <option key={i} value={qus}>{qus}</option>
                    )
                  })
                }
              </Form.Select>
              <div className='meassage-error'>
                <p>{ErrorMessageData.questionError ? ErrorMessageData.questionError : ''}</p>
              </div>
              <Form.Control
                type="text"
                name="answer"
                className='mt-4'
                placeholder='Security Answer'
                onChange={(e) => GetInputValue(e)}
                aria-describedby="inputAnswer"
                value={OnePersonData.answer ? OnePersonData.answer : ''}
              />
              <div className='meassage-error'>
                <p>{ErrorMessageData.answerError ? ErrorMessageData.answerError : ''}</p>
              </div>
              <div className='d-flex justify-content-between '>
                <a href='javscript:void' className='py-2 px-5 bg-black text-white rounded-3' eventKey="basic" onClick={() => setToggleBtn('basic')} >Back</a>
                <NavLink className='bg-black text-white py-2 px-5 border-0 rounded-3' eventKey="personal" onClick={() => setToggleBtn('personal')}>Continue</NavLink>
              </div>
             
            </Col>
          </Row>
        </Form>
      </div >
    </>
  )
}

export default BasicDetails