import React, { useEffect, useState } from 'react'
import { Table } from 'react-bootstrap'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
const ViewData = () => {
      const [viewDataShow, setViewDataShow] = useState([])
      useEffect(() => {
            let data = JSON.parse(localStorage.getItem('UserData'))
            setViewDataShow(data ? data : [])
      }, [])
      return (

            <div className='py-5'>
                  <h2 className='text-center mb-5'>Registration Data</h2>
                  <Container >
                        <Row>
                              <Col className='col-12'>
                                    {
                                          viewDataShow.map((items, pos) => {

                                                return (
                                                      <div className='my-5'>
                                                            <Table className='border border-3' style={{ textTransform: 'capitalize' }}>
                                                                  <tbody>
                                                                        <tr className='text-center' >
                                                                              <th colSpan={2} className='bg-black text-white fs-4'>{++pos}</th>

                                                                        </tr>
                                                                        <tr className='text-center '  >
                                                                              <th colSpan={2} className='bg-primary-subtle '>Basic Details</th>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>userName</th>
                                                                              <td>{items.username}</td>
                                                                        </tr>

                                                                        <tr>
                                                                              <th>language</th>
                                                                              <td>{items.language}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>question</th>
                                                                              <td>{items.question}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>answer</th>
                                                                              <td>{items.answer}</td>
                                                                        </tr>
                                                                        <tr className='text-center' >
                                                                              <th colSpan={2} className='bg-primary-subtle '>Personal Details</th>
                                                                        </tr>
                                                                        <tr>
                                                                              <th> firstName</th>
                                                                              <td>{items.firstName}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>  middleName</th>
                                                                              <td>{items.middleName}</td>
                                                                        </tr>
                                                                        <tr>

                                                                              <th>lastName</th>
                                                                              <td>{items.lastName}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>occupation</th>
                                                                              <td>{items.occupation}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Date Of Birth</th>
                                                                              <td>{items.date}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Unmarried/Married</th>
                                                                              <td>{items.maritalStatus} </td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>gender</th>
                                                                              <td>{items.gender}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Country</th>
                                                                              <td>{items.country}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>email</th>
                                                                              <td>{items.email}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Phone Number</th>
                                                                              <td>{items.phone1}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Nationality</th>
                                                                              <td>{items.nationality}</td>
                                                                        </tr>
                                                                        <tr className='text-center' >
                                                                              <th colSpan={2} className='bg-primary-subtle '>Address</th>
                                                                        </tr>

                                                                        <tr>
                                                                              <th>Flat/Door/Block No.</th>
                                                                              <td>{items.blockNo}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Street/Lane (Optional)</th>
                                                                              <td>{items.Street}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Area/Locality (Optional)</th>
                                                                              <td>{items.Location}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>city</th>
                                                                              <td>{items.city}</td>

                                                                        </tr>
                                                                        <tr>
                                                                              <th>pin code</th>
                                                                              <td>{items.pinCode}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Post Office</th>
                                                                              <td>{items.postOffice}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>State</th>
                                                                              <td>{items.State}</td>
                                                                        </tr>
                                                                        <tr>
                                                                              <th>Phone</th>
                                                                              <td>{items.phone2}</td>
                                                                        </tr>
                                                                  </tbody>

                                                            </Table>
                                                      </div>
                                                )


                                          })
                                    }
                              </Col>
                        </Row>
                  </Container>


            </div>



      )
}

export default ViewData