import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
const Header = () => {
      return (
            <div>
                  <Navbar expand="lg" className="bg-body-tertiary">
                        <Container className=' '>
                              <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
                              <Navbar.Toggle aria-controls="basic-navbar-nav" />
                              <Navbar.Collapse id="basic-navbar-nav ">
                                    <Nav className="me-auto w-100 justify-content-end">
                                          <Nav.Link href="#home" className='py-2 px-4 border border-1 border-black  rounded-3 text-black d-inline-block'><Link to='/' className='text-black'>Registration</Link></Nav.Link>
                                          <Nav.Link href="#link" className='py-2 px-4 border ms-4 border-1 border-black  rounded-3 text-black d-inline-block'><Link to='/view' className='text-black ' >View</Link></Nav.Link>

                                    </Nav>
                              </Navbar.Collapse>
                        </Container>
                  </Navbar>
            </div>
      )
}

export default Header