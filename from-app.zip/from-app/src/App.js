

import { BrowserRouter, Route, Routes } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Registration from './Components/Registration';
import './App.css'
import ViewData from "./Components/ViewData";
import Header from "./Components/Header";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='/' element={< Registration />} />
          <Route path='/view' element={< ViewData />} />

        </Routes>
      </BrowserRouter>
    </div >
  );
}

export default App;
