export const Language = ['Hind', 'English', 'Gujarati']


export const Qus = ['What is your pet name?', 'What was the name of your first school?', 'Who was your Childhood hero?', 'What is your favorite past-time?', 'What is your all time favorite sports team?', 'What is your fathers middle name?', 'What make was your first car or bike?', 'Where did you first meet your spouse?']



export const Occupation = ['GOVERNMENT', 'PUBLIC', 'PRIVATE', 'PROFESSIONAL', 'SELF EMPLOYED', 'STUDENT', 'OTHER']


export const Country = ['United States', 'Canada', 'United Kingdom', 'Germany', 'France', 'Italy', 'Spain', 'Japan', 'China', 'India', 'Brazil', 'Mexico', 'Australia', 'South Korea', 'Netherlands', 'Sweden', 'Norway', 'Denmark', 'Finland', 'Switzerland', 'Russia', 'South Africa', 'Argentina', 'Chile', 'Colombia', 'Egypt', 'Nigeria', 'Kenya', 'Saudi Arabia']


