import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './Components/Header';
import Dashboard from './Components/Dashboard';
import View_Admin from './Components/View_Admin';
import UpData from './Components/UpData';
import BookAdd from './Components/Books/BookAdd';
import BookView from './Components/Books/BookView';
import Add_Admin from './Components/Add_Admin';
import BookUpdata from './Components/Books/BookUpdata';


import './App.css'
function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='/' element={<Dashboard />} />
          <Route path='/addadmin' element={<Add_Admin />} />
          <Route path='/viewadmin' element={<View_Admin />} />
          <Route path='/viewadmin/updata/:id' element={<UpData />} />
          <Route path='/bookadd' element={<BookAdd />} />
          <Route path='/bookview' element={<BookView />} />
          <Route path='/bookview/bookupdata/:id' element={<BookUpdata />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
