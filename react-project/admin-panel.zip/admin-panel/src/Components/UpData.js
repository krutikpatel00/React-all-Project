import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Link } from 'react-router-dom'
const UpData = () => {
      const [User, setUser] = useState({})
      const { id } = useParams()
      const navigation = useNavigate()
      useEffect(() => {
            fetch(`http://localhost:3000/user/${id}`, {
                  method: 'get',
            }).then(async (res) => {
                  let data = await res.json()
                  setUser(data)
            })
                  .catch((error) => console.log('get error Updata:' + error))
      }, [id, setUser])


      const GetInputValue = (e) => {
            const name = e.target.name
            const value = e.target.value
            const data = { ...User, [name]: value }
            setUser(data)
      }
      const DataSubmit = (e) => {
            e.preventDefault();

            fetch(`http://localhost:3000/user/${id}`, {
                  method: 'put',
                  body: JSON.stringify(User)
            }).then((res) => {
                  if (!res.ok) {
                        throw new Error('Failed to add post');
                  }
                  return res.json()
            }).then((data) => {
                  console.log('Post added: ', data);

                  setUser(data)
                  navigation('/viewadmin')
            }).catch(error => {
                  console.error('Error adding post: ', error);
            });

      }
      return (
            <div className="page-wrapper">
                  {/* ============================================================== */}
                  {/* Bread crumb and right sidebar toggle */}
                  {/* ============================================================== */}
                  <div className="page-breadcrumb">
                        <div className="row">
                              <div className="col-12 d-flex no-block align-items-center">
                                    <h4 className="page-title">Form Basic</h4>
                                    <div className="ml-auto text-right">
                                          <nav aria-label="breadcrumb">
                                                <ol className="breadcrumb">
                                                      <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                                      <li className="breadcrumb-item active" aria-current="page">Library</li>
                                                </ol>
                                          </nav>
                                    </div>
                              </div>
                        </div>
                  </div>
                  {/* ============================================================== */}
                  {/* End Bread crumb and right sidebar toggle */}
                  {/* ============================================================== */}
                  {/* ============================================================== */}
                  {/* Container fluid  */}
                  {/* ============================================================== */}
                  <div className="container-fluid">
                        {/* ============================================================== */}
                        {/* Start Page Content */}
                        {/* ============================================================== */}
                        <div className="row">
                              <div className="col-md-6">
                                    <div className="card">
                                          <form className="form-horizontal" method='post' onSubmit={(e) => DataSubmit(e)}>
                                                <div className="card-body">
                                                      <h4 className="card-title">Personal Info</h4>
                                                      <div className="form-group row">
                                                            <label htmlFor="fname" className="col-sm-3 text-right control-label col-form-label">First Name</label>
                                                            <div className="col-sm-9">
                                                                  <input type="text" name='firstname' value={User.firstname ? User.firstname : ''} className="form-control" id="fname" placeholder="First Name Here" onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>
                                                      <div className="form-group row">
                                                            <label htmlFor="lname" className="col-sm-3 text-right control-label col-form-label">Last Name</label>
                                                            <div className="col-sm-9">
                                                                  <input type="text" name='lastname' className="form-control" id="lname" placeholder="Last Name Here" value={User.lastname ? User.lastname : ''} onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>
                                                      <div className="form-group row">
                                                            <label htmlFor="lname" className="col-sm-3 text-right control-label col-form-label">Email</label>
                                                            <div className="col-sm-9">
                                                                  <input type="email" name='email' className="form-control" id="lname" placeholder="Enter email" value={User.email ? User.email : ''} onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>
                                                      <div className="form-group row">
                                                            <label htmlFor="lname" className="col-sm-3 text-right control-label col-form-label">Password</label>
                                                            <div className="col-sm-9">
                                                                  <input type="password" name='password' value={User.password ? User.password : ''} className="form-control" id="lname" placeholder="Password Here" onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>

                                                      <div className="form-group row">
                                                            <label htmlFor="cono1" className="col-sm-3 text-right control-label col-form-label">Contact No</label>
                                                            <div className="col-sm-9">
                                                                  <input type="text" name='contact' className="form-control" id="cono1" placeholder="Contact No Here" value={User.contact ? User.contact : ''} onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>
                                                      <div className="form-group row">
                                                            <label htmlFor="cono1" className="col-sm-3 text-right control-label col-form-label">Message</label>
                                                            <div className="col-sm-9">
                                                                  <textarea className="form-control" name='message' defaultValue={User.message ? User.message : ''} onChange={(e) => GetInputValue(e)} />
                                                            </div>
                                                      </div>
                                                </div>
                                                <div className="border-top">
                                                      <div className="card-body">
                                                            <button type="submit" value={'submit'} className="btn btn-primary">Add Data</button>
                                                      </div>
                                                </div>
                                          </form>
                                    </div>
                              </div>
                        </div>
                        {/* editor */}

                        {/* ============================================================== */}
                        {/* End PAge Content */}
                        {/* ============================================================== */}
                        {/* ============================================================== */}
                        {/* Right sidebar */}
                        {/* ============================================================== */}
                        {/* .right-sidebar */}
                        {/* ============================================================== */}
                        {/* End Right sidebar */}
                        {/* ============================================================== */}
                  </div>
                  {/* ============================================================== */}
                  {/* End Container fluid  */}
                  {/* ============================================================== */}
                  {/* ============================================================== */}
                  {/* footer */}
                  {/* ============================================================== */}
                  <footer className="footer text-center">
                        All Rights Reserved by Matrix-admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
                  </footer>
                  {/* ============================================================== */}
                  {/* End footer */}
                  {/* ============================================================== */}
            </div>
      )
}

export default UpData