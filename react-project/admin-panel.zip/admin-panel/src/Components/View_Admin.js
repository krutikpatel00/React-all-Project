import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

const View_Admin = () => {

  const [adminData, setAdminData] = useState([])
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(2);
  const [arryCount, setArryCount] = useState([])
  const [Search, setSearch] = useState('')

  useEffect(() => {
    getData()

  }, [setAdminData, setCurrentPage, currentPage])

  const getData = () => {
    fetch('http://localhost:3000/user')
      .then(async (res) => {
        let data = await res.json()
        const nPages = Math.ceil(data.length / recordsPerPage)
        const indexOfLastRecord = currentPage * recordsPerPage;
        const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
        let pages = []
        for (let i = 1; i <= nPages; i++) {
          pages.push(i)
        }
        setArryCount(pages)
        const currentRecords = data.slice(indexOfFirstRecord,
          indexOfLastRecord);
        console.log(currentRecords);
        setAdminData(currentRecords)
      }).catch((error) => {
        console.log("this data" + error);
      })
  }
  const DataDelete = (id) => {
    fetch(`http://localhost:3000/user/${id}`, {
      method: 'delete'
    }).then((res) => {
      getData()
    }).catch((error) => {
      console.log("this data" + error);
    })
  }

  const nextPage = (pages) => {
    setCurrentPage(pages)
    console.log(pages);
  }
  return (
    <div className="page-wrapper">
      {/* ============================================================== */}
      {/* Bread crumb and right sidebar toggle */}
      {/* ============================================================== */}
      <div className="page-breadcrumb">
        <div className="row">
          <div className="col-12 d-flex no-block align-items-center">
            <h4 className="page-title">Tables</h4>
            <div className="ml-auto text-right">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item"><a href="#">Home</a></li>
                  <li className="breadcrumb-item active" aria-current="page">Library</li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
      {/* ============================================================== */}
      {/* End Bread crumb and right sidebar toggle */}
      {/* ============================================================== */}
      {/* ============================================================== */}
      {/* Container fluid  */}
      {/* ============================================================== */}
      <div className="container-fluid">
        {/* ============================================================== */}
        {/* Start Page Content */}
        {/* ============================================================== */}
        <div className="row">
          <div className="col-12">
            <div className="card">
              <div className="card-body d-flex justify-content-between">
                <h5 className="card-title m-b-0">Static Table</h5>
                <div>
                  <label>Search </label>
                  <input type="text" name='search' onChange={(e) => setSearch(e.target.value)} />
                </div>
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>
                    <th scope="col">Contect</th>
                    <th scope="col">message</th>
                    <th scope="col">Delete</th>
                    <th scope="col">UpData</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    adminData.filter((items) => {
                      return (
                        items.firstname.match(Search)
                      )
                    }).map((item, pos) => {
                      return (
                        <tr key={item.id}>
                          <th scope="row">{++pos}</th>
                          <td>{item.firstname}</td>
                          <td>{item.lastname}</td>
                          <td>{item.email}</td>
                          <td>{item.password}</td>
                          <td>{item.contact}</td>
                          <td>{item.message}</td>
                          <td>
                            <Link className='button-btn' onClick={(e) => DataDelete(item.id)}>Delete</Link>
                          </td>
                          <td>
                            <Link className='button-btn' to={'/viewadmin/updata/' + item.id}>Updata</Link>
                          </td>
                        </tr>
                      )
                    })
                  }
                  <tr>
                    <td colSpan={9} className=''>
                      {
                        arryCount.map((items) => {
                          return (
                            <button className='pagination-btn' onClick={() => nextPage(items)}>{items}</button>
                          )
                        })
                      }
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>


          </div>
        </div>
        {/* ============================================================== */}
        {/* End PAge Content */}
        {/* ============================================================== */}
        {/* ============================================================== */}
        {/* Right sidebar */}
        {/* ============================================================== */}
        {/* .right-sidebar */}
        {/* ============================================================== */}
        {/* End Right sidebar */}
        {/* ============================================================== */}
      </div>
      {/* ============================================================== */}
      {/* End Container fluid  */}
      {/* ============================================================== */}
      {/* ============================================================== */}
      {/* footer */}
      {/* ============================================================== */}
      <footer className="footer text-center">
        All Rights Reserved by Matrix-admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
      </footer>
      {/* ============================================================== */}
      {/* End footer */}
      {/* ============================================================== */}
    </div>

  )
}

export default View_Admin