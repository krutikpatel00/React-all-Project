import Card from './Components/Card';


function App() {
  return (
    <>
      <main>
        <Card />
      </main>
    </>
  );
}

export default App;
