import React, { useEffect, useState } from 'react'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Row, Container, Col, ButtonGroup } from 'react-bootstrap'
import axios from 'axios'
import Loding from './Loding';

const Product = () => {
     const [Product, setProduct] = useState()
     const [Categories, setCategories] = useState()
     const [isLoading, setLoading] = useState(true)
     useEffect(() => {
          ProductDataGet()
          ProductCategoriesGet()
     }, [setProduct])

     const ProductDataGet = () => {
          axios.get(`https://fakestoreapi.com/products`)
               .then((res) => {    
                  
                         setProduct(res.data)
                         console.log(res.data);
                  
                   
               })
               .catch((err) => {
                    console.log(err);
               })
     }
     const ProductCategoriesGet = () => {
          axios.get(`https://fakestoreapi.com/products/categories`)
               .then((res) => {
                    setCategories(res.data)

               })
               .catch((err) => {
                    console.log(err);
               })
     }
     const ShowCategories = (categoriesName) => {
          axios.get(`https://fakestoreapi.com/products/category/${categoriesName}`)
               .then((res) => {
                    setProduct(res.data)
               })
     }
     return (
          <Container>
               <h1 className="text-center mt-5">Products</h1>
               <ButtonGroup aria-label="Basic example">
                    {Categories?.map((v, i) => {
                         return (
                              <Button variant="secondary" onClick={() => ShowCategories(v)}>{v}</Button>
                         )
                    })}

               </ButtonGroup>
               <Row className="">
                    {
                         Product?.map((v, i) => {
                              return (<Col className='col-3 m-0 p-0 h-100'>
                                   <Card className='p-4 h-100 m-1'>
                                        <Card.Img variant="top" src={v.image} className='object-fit-contant' width={'100%'} height={'300px'} />
                                        <Card.Body>
                                             <Card.Title>{v.title.slice(0, 30)}</Card.Title>
                                             <Card.Text className=''>
                                                  {
                                                       v.description.slice(0, 80)
                                                  }...
                                             </Card.Text>
                                             <Button variant="primary">view</Button>
                                        </Card.Body>
                                   </Card>
                              </Col>)
                         })
                    }
               </Row>
          </Container>
     )
}

export default Product