import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Product from './Components/Product';
function App() {
  return (
   <>
<Product/>
   </>
  );
}

export default App;
