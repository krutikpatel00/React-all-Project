import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './Components/Header';
import Dashboard from './Components/Dashboard';
import Add_Admin from './Components/Add_Admin';
import View_Admin from './Components/View_Admin';

function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='/' element={<Dashboard />} />
          <Route path='/addadmin' element={<Add_Admin />} />
          <Route path='/viewadmin' element={<View_Admin />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
