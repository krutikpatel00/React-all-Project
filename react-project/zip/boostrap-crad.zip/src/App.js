import Card from "./Components/Card";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <>
      <main>
        <Card />
      </main>
    </>
  );
}

export default App;
