import React, { useEffect, useState } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Table from 'react-bootstrap/Table';


const Card = () => {
      const [InputData, setInputData] = useState({});
      const [alldata, setAllData] = useState([]);
      const [IdData, setIdData] = useState(0);

      useEffect(() => {
            const data = sessionStorage.getItem('student');
            setAllData(data !== null ? JSON.parse(data) : [])
      }, [])

      const inputDataValue = (e) => {
            const name = e.target.name
            const value = e.target.value
            const data = { ...InputData, [name]: value }
            setInputData(data)
      }
      const DataSubmit = (e) => {
            e.preventDefault()
            if (IdData === 0) {
                  const id = Math.floor(Math.random() * 1000)
                  const data = [...alldata, { ...InputData, id }]
                  setAllData(data)
                  sessionStorage.setItem('student', JSON.stringify(data))
                  console.log('dkf');
            } else {
                  const index = alldata.findIndex(value => value.id === IdData)
                  const updatedData = [...alldata];
                  updatedData[index] = { ...InputData, id: IdData }
                  setAllData(updatedData);
                  sessionStorage.setItem('student', JSON.stringify(updatedData))
                  setIdData(0)
            }
      }
      const DataDelete = (userId) => {
            const data = alldata.filter(value => value.id !== userId)
            setAllData(data)
            sessionStorage.setItem('student', JSON.stringify(data))
      }
      const DataUpdata = (userId) => {
            const index = alldata.findIndex(value => value.id === userId)
            setInputData(alldata[index])
            setIdData(userId)
      }
      console.log(InputData);
      return (
            <div>
                  <Form onSubmit={(e) => DataSubmit(e)}>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Email address</Form.Label>
                              <Form.Control type="email" name='email' value={InputData.email ? InputData.email : ''} placeholder="Enter email" onChange={(e) => inputDataValue(e)} />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                              <Form.Label>Password</Form.Label>
                              <Form.Control type="password" name='password' value={InputData.password ? InputData.password : ''} placeholder="Password" onChange={(e) => inputDataValue(e)} />
                        </Form.Group>

                        <Button variant="primary" type="submit">
                              {IdData === 0 ? 'Submit' : 'Update'}
                        </Button>
                  </Form>
                  <Table striped bordered hover>
                        <thead>
                              <tr>
                                    <th>#</th>
                                    <th>email</th>
                                    <th>password</th>

                              </tr>
                        </thead>
                        <tbody>
                              {
                                    alldata.map((v, index) => {
                                          return (
                                                <tr key={index}>
                                                      <th>{++index}</th>
                                                      <th>{v.email}</th>
                                                      <th>{v.password}</th>
                                                      <th>
                                                            <Button onClick={(e) => DataDelete(v.id)} variant="danger">Delete</Button>
                                                      </th>
                                                      <th>
                                                            <Button onClick={(e) => DataUpdata(v.id)} variant="primary">Updata</Button>
                                                      </th>
                                                </tr>
                                          )
                                    })
                              }
                        </tbody>
                  </Table>
            </div>
      )
}

export default Card