
import 'bootstrap/dist/css/bootstrap.min.css';
import SignUp from './Components/SignUp/SignUp';
import LogIn from './Components/LogIn/LogIn';
import Header from './Components/Header/Header';
import { BrowserRouter, Route, Routes } from 'react-router-dom';


function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path='/' element={<SignUp />} />
        <Route path='/login' element={<LogIn />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
