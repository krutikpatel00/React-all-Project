
const MusicAudio = [

      {
            name: 'shivagi',
            musicAudio: require('../Audio/shivagi.mp3'),
            img: require('../Assets/Images/sivaji.jpg')

      },
      {
            name: 'KGFChapter2',
            musicAudio: require('../Audio/KGFChapter2.mp3'),
            img: require('../Assets/Images/kgf2.jpg')
      },
      {
            name: 'SalaarPrabhas',
            musicAudio: require('../Audio/SalaarPrabhas.mp3'),
            img: require('../Assets/Images/salar.jpg')
      },
      {
            name: 'aarambh',
            musicAudio: require('../Audio/Aarambh.mp3'),
            img: require('../Assets/Images/aarambh.jpg')
      },
      {
            name: 'jootajapni',
            musicAudio: require('../Audio/jootajpani.mp3'),
            img: require('../Assets/Images/jootajapni.jpg')
      },


]

export default MusicAudio