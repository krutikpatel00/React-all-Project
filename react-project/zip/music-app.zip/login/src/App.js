
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Music from './Components/Music';


function App() {
  return (
    <BrowserRouter>
     
      <Routes>
        <Route path='/' element={<Music />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
