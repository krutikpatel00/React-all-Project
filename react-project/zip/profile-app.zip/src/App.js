import Profiles from "./Components/Profiles";


function App() {
  return (
    <>
      <main>
        <Profiles></Profiles>
      </main>
    </>
  );
}

export default App;
