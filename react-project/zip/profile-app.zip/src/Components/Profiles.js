import React from 'react'
import './Profiles.css'
import { FaEdit } from "react-icons/fa";
import { IoMedkit } from "react-icons/io5";
import { FaRegStar } from "react-icons/fa";
import { IoIosArrowDropright } from "react-icons/io";
import profileImg from '../Assets/Images/profile-img.avif'


const Profiles = () => {
      return (
            <section className='profile'>
                  <div className="container">
                        <div className='profile-inner'>
                              <div className='profile-banner-img'>
                                    <a href='javscript:void(0)' className='eddit-items'>
                                          <FaEdit ></FaEdit>
                                    </a>
                              </div>
                              <div className='profile-detile'>
                                    <div className='profile-items row align-items-center justify-content-between'>
                                          <img src={profileImg} alt="" className='profileImg' />
                                          <h6>Current role <IoMedkit></IoMedkit></h6>
                                    </div>
                                    <ul className='profile-name row align-items-center justify-content-between'>
                                          <li>
                                                <h2>Emma samith</h2>
                                          </li>
                                          <li>
                                                <p>Software Engineer</p>
                                          </li>
                                    </ul>
                                    <ul className='profile-skill row align-items-center justify-content-between'>
                                          <li>
                                                <p>Software Engineer <br /> Los Angeles, California</p>

                                          </li>
                                          <li>
                                                <p>Skills <FaRegStar></FaRegStar></p>
                                          </li>
                                    </ul>
                                    <ul className='row profile-btn-skill  align-items-center justify-content-between'>
                                          <li>
                                                <div className='profile-btn'>
                                                      <button className='edit-btn'>Edit Profile</button>
                                                      <button className='settings-btn'>Settings</button>
                                                </div>

                                          </li>
                                          <li>
                                                <ul className='row'>
                                                      <li><a href={'/'}>HTML</a></li>
                                                      <li><a href={'/'}>CSS</a></li>
                                                      <li><a href={'/'}>Dart</a></li>
                                                      <li><a href={'/'}>C++</a></li>
                                                      <li><a href={'/'}>UI Design</a></li>
                                                </ul>
                                          </li>
                                    </ul>
                                    <div className='row profile-reade'>
                                          <div className="w-1 w-md-2">
                                                <div className='profile-content'>
                                                      <ul className='d-flex justify-content-between align-items-center'>
                                                            <li>  <h2>Ready for work</h2>
                                                                  <p>Show recruiters that you're ready for work.</p></li>
                                                            <li>
                                                                  <a href="/">
                                                                        <IoIosArrowDropright className='arrow-icon'></IoIosArrowDropright>
                                                                  </a>
                                                            </li>
                                                      </ul>
                                                </div>
                                          </div>
                                          <div className="w-1 w-md-2">
                                                <div className='profile-content'>
                                                      <ul className='d-flex justify-content-between align-items-center'>
                                                            <li>  <h2>Ready for work</h2>
                                                                  <p>Show recruiters that you're ready for work.</p></li>
                                                            <li>
                                                                  <a href="/">
                                                                        <IoIosArrowDropright className='arrow-icon'></IoIosArrowDropright>
                                                                  </a>
                                                            </li>
                                                      </ul>
                                                </div></div>
                                          <div className="w-1 w-md-2">
                                                <div className='profile-content'>
                                                      <ul className='d-flex justify-content-between align-items-center'>
                                                            <li>  <h2>Ready for work</h2>
                                                                  <p>Show recruiters that you're ready for work.</p></li>
                                                            <li>
                                                                  <a href="/">
                                                                        <IoIosArrowDropright className='arrow-icon'></IoIosArrowDropright>
                                                                  </a>
                                                            </li>
                                                      </ul>
                                                </div>
                                          </div>
                                    </div>
                              </div>

                        </div>
                  </div>
            </section >
      )
}

export default Profiles
