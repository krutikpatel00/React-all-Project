import React, { useState } from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image';
import Img from '../Assets/Images/img-1.jpeg'
import GoogleImg from '../Assets/Images/google 1.png'
import FacebookImg from '../Assets/Images/facebook 1.png'
import './Loing.css'
const Loing = () => {
      const [LogIn, setLogIn] = useState(false);
      console.log(LogIn);
      return (
            <section className='login-inner'>
                  <Container>
                        <Row>
                              <Col className='col-lg-6 col-12 '>
                                    <div className='login-content position-relative z-1'>
                                          <h2>Create Account</h2>
                                          <a href='javscript:void' className='d-flex align-items-center justify-content-center border border-2 rounded-3 py-2 my-3'>
                                                <p className='text-black  me-3'>{LogIn === true ? 'Sign In with Google ' : 'Sign Up with Google '}</p>
                                                <img src={GoogleImg} alt="" />
                                          </a>
                                          <a href='javscript:void' className='d-flex align-items-center  justify-content-center border border-2 rounded-3 py-2 my-3'>
                                                <p className='text-black me-3'>{LogIn === true ? 'Sign In with Facebbok' : 'Sign Up with Facebbok '}</p>
                                                <img src={FacebookImg} alt="" />
                                          </a>
                                          <div>
                                                <p className='text-center py-2 '>Or</p>
                                          </div>
                                          <div>
                                                <form
                                                      className='d-flex flex-column'>
                                                      <input style={{ display: `${LogIn === true ? 'none' : 'block'}` }}
                                                            type="text"
                                                            placeholder='Full Name'
                                                            className='py-2 px-3 border border-2 rounded-5 my-2' />
                                                      <input
                                                            type="text"
                                                            placeholder='Email Address'
                                                            className='py-2 px-3 border border-2 rounded-5 my-2' />
                                                      <input
                                                            type="text"
                                                            placeholder='Password' className='py-2 px-3 border border-2 rounded-5 my-2' />
                                                      <input
                                                            type="submit"
                                                            value={LogIn === true ? 'LogIn Account' : 'Create Account'}
                                                            className='py-2 px-3 border border-2 rounded-5 my-2 text-white bg-black fs-5' />
                                                </form>
                                          </div>
                                          <p
                                                className='text-center'>{LogIn === true ? 'Creact new account? ' : 'Do you already have an account? '}
                                                {LogIn === true ? <a href="javscript:void(0)" className='text-primary' onClick={() => setLogIn(false)}> Sign Up</a> : <a href="javscript:void(0)" className='text-primary' onClick={() => setLogIn(true)}> Log In</a>}</p>
                                    </div>

                              </Col>
                              <Col className='col-lg-6 col-12'>
                                    <div className='login-img h-100'>
                                          <Image src={Img} alt="" className='w-100 h-100 object-fit-cover' />
                                    </div>
                              </Col>

                        </Row>
                  </Container>
            </section>
      )
}
export default Loing