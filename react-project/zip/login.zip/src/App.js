import Loing from "./Components/Loing";
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <>
      <main>
        <Loing />
      </main>
    </>
  );
}

export default App;
