import Feedback from './Components/Feedback';
import './index.css'


function App() {
  return (
    <>
      <Feedback />
     
    </>
  );
}

export default App;
