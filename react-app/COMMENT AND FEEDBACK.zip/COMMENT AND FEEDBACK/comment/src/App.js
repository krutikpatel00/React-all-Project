
import Comment from './Components/Comment';
import './index.css'
function App() {
  return (
    <>
      <Comment />
    </>
  );
}

export default App;
