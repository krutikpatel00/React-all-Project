import React, { useState } from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios'
import { useDispatch } from 'react-redux';
import { ProductAdd } from '../../Redux/Action/ProductAction';

const ProductListAdd = () => {


      const [ProductData, setProductData] = useState({})
      const dispatch = useDispatch()
      const [Error, setError] = useState(null)
      const onlyNumbers = /^\d+$/

      const GetInputValue = (e) => {
            const name = e.target.name;
            const value = e.target.value;
            const data = { ...ProductData, [name]: value }
            setProductData(data)
            console.log(data);
      }

      const ProudctSubmit = (e) => {
            e.preventDefault()

            if (ProductData.title === undefined) {
                  toast.error('Required Product Title Field')
            } else if (ProductData.title.length <= 3) {
                  toast.error('Required Product Title More Then 3 Careter Field')
            } else if (ProductData.price === undefined) {
                  toast.error('Required Product Price Field')
            } else if (!(ProductData.price.match(onlyNumbers))) {
                  toast.error('Required Only Numbers Field')
            } else if (ProductData.oldPrice === undefined) {
                  toast.error('Required Product OldPrice Field')
            } else if (ProductData.image === undefined) {
                  toast.error('Required Product Image Field')
            } else if (ProductData.description === undefined) {
                  toast.error('Required Product Description Field')
            } else {
                  toast.success(`Product successfully added`)
                  axios.post(`http://localhost:3000/Product`, ProductData).then((res) => {
                        dispatch(ProductAdd(res.data))
                  }).catch((error) => {
                        setError(error)
                  })
                  setProductData({})
            }
      }
      if (Error) {
            return <div className=''>
                  <div>{Error.message}</div>
            </div>
      }

      return (
            <Container>
                  <Row>
                        <Col>
                              <Form method='post' onSubmit={(e) => ProudctSubmit(e)}>
                                    <Form.Group className="mb-3" controlId="formGroupTitle">
                                          <Form.Label>Title</Form.Label>
                                          <Form.Control type="text" placeholder="Enter Title" name='title' value={ProductData.title ? ProductData.title : ''} onChange={(e) => GetInputValue(e)} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="formGroupPrice">
                                          <Form.Label>Product Price</Form.Label>
                                          <Form.Control type="text" placeholder="Enter Price" value={ProductData.price ? ProductData.price : ''} name='price' onChange={(e) => GetInputValue(e)} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="formGroupOldPrice">
                                          <Form.Label>Product Old Price</Form.Label>
                                          <Form.Control type="text" placeholder="Enter Old Price" name='oldPrice' value={ProductData.oldPrice ? ProductData.oldPrice : ''} onChange={(e) => GetInputValue(e)} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="formGroupImage">
                                          <Form.Label>Product Image</Form.Label>
                                          <Form.Control type="url" placeholder="Enter Url Image" name='image' value={ProductData.image ? ProductData.image : ''} onChange={(e) => GetInputValue(e)} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                          <Form.Label>Example textarea</Form.Label>
                                          <Form.Control as="textarea" rows={3} name='description' value={ProductData.description ? ProductData.description : ''} onChange={(e) => GetInputValue(e)} />
                                    </Form.Group>
                                    <Button variant="primary" type='submit'>Primary</Button>
                              </Form>
                        </Col>
                  </Row>
                  <ToastContainer />
            </Container>
      )
}

export default ProductListAdd