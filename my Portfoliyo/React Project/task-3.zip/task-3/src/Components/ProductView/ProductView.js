import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Image } from 'react-bootstrap'
import axios from 'axios'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { ProductSorts, ProductViews } from '../../Redux/Action/ProductAction';

const ProductView = () => {
      const Product = useSelector(state => state.ProductReducer.Product)
      const [paginationData, setPageinationData] = useState([])
      const [PerPage, setPerPage] = useState(1)
      const [perpageRecord, setPerPageRecord] = useState(8)
      const [btnPage, setBtnPage] = useState([])
      const [SortPrice, setSortPrice] = useState(null)
      const [Search, setSearch] = useState('')
      const [Error, setError] = useState(null)
      const dispatch = useDispatch()

      useEffect(() => {
            pagination()
            axios.get(`http://localhost:3000/Product`).then((res) => {
                  let data = res.data
                  if (SortPrice !== null) {
                        if (SortPrice) {
                              data = res.data.sort((a, b) => {
                                    return a.price < b.price ? -1 : 1
                              })

                        } else {
                              data = res.data.sort((a, b) => {
                                    return a.price < b.price ? 1 : -1
                              })
                        }
                  }

                  const lastIndex = PerPage * perpageRecord;
                  const fistIndex = lastIndex - perpageRecord

                  const currentPageData = data.slice(fistIndex, lastIndex)
                  const nPage = Math.ceil(data.length / perpageRecord)
                  const btnArry = [...Array(nPage + 1).keys()].slice(1)
                  setBtnPage(btnArry)

                  // setPageinationData(currentPageData)
                  dispatch(ProductViews(currentPageData))
            }).catch((error) => {
                  setError(error)
            })
      }, [PerPage, SortPrice, setSortPrice, perpageRecord, setPageinationData])


      const pagination = () => {


      }


      const ProductSort = (e) => {
            setSortPrice(!SortPrice)

      }

      if (Error) {
            return <div className='d-flex justify-content-center align-items-center' style={{ height: '100vh' }}>
                  <div>{Error.message}</div>
            </div>
      }

      return (
            <div className='container'>
                  <div className='my-4 d-flex'>
                        <Form.Control type="text" className='w-100' name='search' onChange={(e) => setSearch(e.target.value)} />
                        <button className='btn bg-primary-subtle ms-2' onClick={() => ProductSort()}>Sort</button>
                  </div>
                  <div className='row align-items-center'>
                        {
                              Product.filter((item) => {
                                    return item.title.toLocaleLowerCase().match(Search.toLocaleLowerCase())
                              }).map((item, pos) => {
                                    return (
                                          <div className='col-3' key={pos}>
                                                <div className='border p-4 m-2 rounded-3'>
                                                      <div >
                                                            <Image src={item.image} className='w-100' />
                                                      </div>
                                                      <h5 className='pt-3'>{item.title}</h5>
                                                      <p className='my-1'>{item.description.slice(0, 80)}</p>
                                                      <div className='d-flex'>
                                                            <h4 className='me-4'>{Number(item.oldPrice).toLocaleString()}</h4>
                                                            <h4 className='text-decoration-line-through text-secondary'>{Number(item.price).toLocaleString()}</h4>
                                                      </div>
                                                      <Button variant="primary" className='mt-2'>View</Button>
                                                </div>
                                          </div>
                                    )
                              })
                        }
                  </div>
                  <div className='mt-4'>
                        {
                              btnPage.map((items, pos) => {
                                    return (
                                          <button className='btn bg-primary-subtle mx-1' value={items} onClick={(e) => setPerPage(e.target.value)}>{items}</button>
                                    )
                              })
                        }
                  </div>
            </div>
      )
}

export default ProductView