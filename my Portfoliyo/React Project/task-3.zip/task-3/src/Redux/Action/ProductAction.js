
export const PRODUCT_ADD_PRODUCT = `PRODUCT_ADD_PRODUCT`
export const PRODUCT_VIEW_PRODUCT = `PRODUCT_VIEW_PRODUCT`
export const PRODUCT_SORT_PRODUCT = `PRODUCT_SORT_PRODUCT`

export const ProductViews = (data) => ({
      type: PRODUCT_VIEW_PRODUCT,
      payload: data
})

export const ProductAdd = (data) => ({
      type: PRODUCT_ADD_PRODUCT,
      payload: data
})

export const ProductSorts = (data) => ({
      type: PRODUCT_SORT_PRODUCT,
      payload: data
})