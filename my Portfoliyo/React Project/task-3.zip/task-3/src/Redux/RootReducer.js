


import { combineReducers } from 'redux'
import ProductReducer from './Reducer/ProductReducer'

const RootReducer = combineReducers({
      ProductReducer
})

export default RootReducer