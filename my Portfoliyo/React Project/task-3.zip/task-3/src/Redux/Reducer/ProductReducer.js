import { PRODUCT_ADD_PRODUCT, PRODUCT_SORT_PRODUCT, PRODUCT_VIEW_PRODUCT } from "../Action/ProductAction";


const ins = {
      Product: []
}


const ProductReducer = (state = ins, action) => {

      switch (action.type) {
            case PRODUCT_VIEW_PRODUCT:
                  return {
                        ...state,
                        Product: action.payload
                  }

            case PRODUCT_ADD_PRODUCT:
                  return {
                        ...state,
                        Product: [...state.Product, action.payload]
                  }
            case PRODUCT_SORT_PRODUCT:
                  return {
                        ...state,
                        Product: action.payload
                  }
            default:
                  return state
      }

}

export default ProductReducer