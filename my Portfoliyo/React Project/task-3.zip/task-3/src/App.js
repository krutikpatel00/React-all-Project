import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ProductListAdd from './Components/ProductListAdd/ProductListAdd';
import ProductView from './Components/ProductView/ProductView';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Components/Header/Header';



function App() {
  return (<>
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path='/' element={<ProductListAdd />}></Route>
        <Route path='/Productview' element={<ProductView />}></Route>
      </Routes>
    </BrowserRouter>
  </>
  );
}

export default App;
