import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import TodoAdd from './Components/Todo/TodoAdd';
import TodoView from './Components/Todo/TodoView';
import Header from './Components/Header/Header';
import 'react-toastify/dist/ReactToastify.css';
import 'remixicon/fonts/remixicon.css'

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path='/' element={< TodoAdd />}></Route >
        <Route path='/todoview' element={<TodoView />}></Route >
      </Routes>
    </BrowserRouter>
  );
}

export default App;
