import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ErrorPage from '../ErrorPage/ErrorPage'
import { Container } from 'react-bootstrap'
import Form from 'react-bootstrap/Form';

import { Link } from 'react-router-dom'

const TaskColor = (task, taskComplets) => {
      if (taskComplets) {
            return 'white'
      } else {
            if (task === 'Office') {
                  return 'red'
            } else if (task === 'Personal') {
                  return "yellow"
            } else if (task === 'Family') {
                  return 'green'
            } else if (task === 'Friends') {
                  return 'cyan'
            } else if (task === 'Other') {
                  return 'gray'
            }
      }
}


const TodoView = () => {

      const [Todo, setTodo] = useState([])
      const [Error, setError] = useState(null)
      const [CurrentPage, setCurrentPage] = useState(1)
      const [RecordPerPage] = useState(6)
      const [btnPage, setBtnPage] = useState([])
      const [Sorting, setSorting] = useState('')
      const [Search, setSerach] = useState('')


      useEffect(() => {
            getInputData()
      }, [Sorting, CurrentPage, setTodo, setSerach])

      const getInputData = () => {
            axios.get(`http://localhost:3000/tasks`).then((res) => {
                  let data = res.data;
                  if (Sorting !== '') {
                        if (Sorting === 'high') {
                              data = res.data.sort((a, b) => a.taskcomplet < b.taskcomplet ? -1 : 1)
                        } else if (Sorting === 'low') {
                              data = res.data.sort((a, b) => a.taskcomplet < b.taskcomplet ? 1 : -1)

                        }
                  }
                  let lastIndex = RecordPerPage * CurrentPage;
                  let fistIndex = lastIndex - RecordPerPage
                  let pageRecord = data.slice(fistIndex, lastIndex)

                  let nPage = Math.ceil((data.length / RecordPerPage))
                  let btnArry = [...Array(nPage + 1).keys()].slice(1)
                  setBtnPage(btnArry)

                  setTodo(pageRecord ? pageRecord : [])
            }).catch((error) => {
                  setError(error)
            })
      }

      const getInputValue = (e, id) => {
            const name = e.target.name
            if (name === 'taskcomplet') {
                  if (e.target.checked) {
                        axios.get(`http://localhost:3000/tasks/${id}`).then((res) => {
                              let data = res.data
                              data.taskcomplet = true

                              axios.put(`http://localhost:3000/tasks/${id}`, data).then((res) => {
                                    getInputData()
                              }).catch((error) => {
                                    setError(error)
                              })
                        }).catch((error) => {
                              setError(error)
                        })
                  } else {
                        axios.get(`http://localhost:3000/tasks/${id}`).then((res) => {
                              let data = res.data
                              data.taskcomplet = false
                              axios.put(`http://localhost:3000/tasks/${id}`, data).then((res) => {
                                    getInputData()
                              }).catch((error) => {
                                    setError(error)
                              })
                        }).catch((error) => {
                              setError(error)
                        })
                  }
            }

      }

      const DeleteItems = (id) => {
            axios.delete(`http://localhost:3000/tasks/${id}`).then((res) => {
                  getInputData()
            }).catch((error) => {
                  setError(error)
            })
      }

      if (Error) {
            return (
                  <ErrorPage error={Error} />
            )
      }

      return (
            <div>
                  <Container>
                        <div className='d-flex justify-content-center align-items-center'>
                              <Form.Control
                                    type="text"
                                    placeholder='search Task'
                                    className='m-3'
                                    id="inputSearch"
                                    onChange={(e) => setSerach(e.target.value)}
                                    aria-describedby="passwordHelpBlock"
                              />
                              <Form.Select onChange={(e) => setSorting(e.target.value)} name='sorting'>
                                    <option disabled selected>SORT</option>
                                    <option value="high">task</option>
                                    <option value="low">Completed task</option>

                              </Form.Select>
                        </div>
                        <div className='row'>
                              {
                                    Todo.filter((items, pos) => {
                                          if (Search !== '') {
                                                return items.task.match(Search) || items.date.match(Search)
                                          }
                                          else {
                                                return items
                                          }
                                    }).map((todo, pos) => {
                                          return (
                                                <div className='col-12 col-md-6 col-lg-4 my-2'>
                                                      <div className='border p-3 rounded-3 h-100' style={{ backgroundColor: TaskColor(todo.taskType, todo.taskcomplet) }}>
                                                            <div className='d-flex justify-content-between align-items-center '>
                                                                  <input type="checkbox" checked={todo.taskcomplet} onChange={(e) => getInputValue(e, todo.id)} className='checkbox-items' name='taskcomplet' />
                                                                  <Link onClick={(e) => DeleteItems(todo.id)} className='fs-5 text-decoration-none text-black'><i class="ri-close-large-line"></i></Link>
                                                            </div>
                                                            <p className='fw-medium border-top mt-3 pt-3 text-justify'>{todo.task}</p>
                                                            <p className='text-end p-2 border-top mt-3'>{todo.date}</p>
                                                      </div>
                                                </div>
                                          )
                                    })
                              }
                        </div>
                        {
                              Todo.length !== 0 ?
                                    <div className='d-flex justify-content-between  align-items-center'>
                                          {
                                                CurrentPage !== btnPage[0] ? <button className='btn bg-black text-white' onClick={() => setCurrentPage(CurrentPage - 1)}>Prev</button> : ''
                                          }
                                          {
                                                CurrentPage !== btnPage.length ? <button className='btn bg-black text-white' onClick={() => setCurrentPage(CurrentPage + 1)}>Next</button> : ''
                                          }
                                    </div> : ''
                        }
                  </Container>

            </div>
      )
}

export default TodoView