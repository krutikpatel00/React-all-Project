import React, { useState } from 'react'
import { Form, Container, Row, Col, FloatingLabel } from 'react-bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import Button from 'react-bootstrap/Button';
import axios from 'axios'
import ErrorPage from '../ErrorPage/ErrorPage';

const taskTypes = ['Office', 'Personal', 'Family', 'Friends', 'Other']

const TodoAdd = () => {

      const [todoAdd, setTodoAdd] = useState({})
      const [Error, setError] = useState(null)

      const getInputValue = (e) => {
            const name = e.target.name
            const value = e.target.value
            const data = { ...todoAdd, [name]: value, taskcomplet: false, }
            setTodoAdd(data)
      }

      const TaskDataSubmit = (e) => {
            e.preventDefault()
            if (todoAdd.username === undefined) {
                  toast.error(`Username is required`)
            }
            else if (todoAdd.date === undefined) {
                  toast.error(`Date is required`)
            }
            else if (todoAdd.taskType === undefined) {
                  toast.error(`Task type is required`)
            }
            else if (todoAdd.task === undefined) {
                  toast.error(`Task is required`)
            }
            else if (todoAdd.task <= 3) {
                  toast.error(`More Than 3 Character Add`)
            }
            else {
                  axios.post(`http://localhost:3000/tasks`, todoAdd).then((res) => {
                        toast.success(`Task Added Successfully`)
                        setTodoAdd({})
                  }).catch((error) => {
                        setError(error);
                  })
            }
      }
      if (Error) {
            return <ErrorPage error={Error} />
      }

      return (
            <div className='my-5'>
                  <Container>
                        <Row>
                              <Col>
                                    <Form method='post' onSubmit={(e) => TaskDataSubmit(e)}>
                                          <Form.Group className="mb-3" controlId="formGroupUserName">
                                                <Form.Label>User Name</Form.Label>
                                                <Form.Control type="text" name='username' value={todoAdd.username ? todoAdd.username : ''} onChange={(e) => getInputValue(e)} placeholder="Enter Tilet" />
                                          </Form.Group>
                                          <Form.Group className="mb-3" controlId="formGroupDate">
                                                <Form.Label>Date</Form.Label>
                                                <Form.Control type="date" placeholder="date" name='date' value={todoAdd.date ? todoAdd.date : ''} onChange={(e) => getInputValue(e)} />
                                          </Form.Group>
                                          <Form.Select aria-label="Default select example" name='taskType' value={todoAdd.taskType ? todoAdd.taskType : 'Open this select task type'} onChange={(e) => getInputValue(e)} className="mb-3">
                                                <option disabled selected value={'Open this select task type'}>Open this select task type </option>
                                                {
                                                      taskTypes.map((item, pos) => {
                                                            return (
                                                                  <option value={item}>{item}</option>
                                                            )
                                                      })
                                                }
                                          </Form.Select>
                                          <FloatingLabel controlId="floatingTextarea2" className="mb-3" label="Task">
                                                <Form.Control
                                                      as="textarea"
                                                      name='task'
                                                      value={todoAdd.task ? todoAdd.task : ''}
                                                      placeholder="task "
                                                      onChange={(e) => getInputValue(e)}
                                                      style={{ height: '100px' }}
                                                />
                                          </FloatingLabel>
                                          <Button variant="secondary" className="mb-3" type='submit'>Task Add</Button>
                                    </Form>
                              </Col>
                        </Row>
                  </Container>
                  <ToastContainer />
            </div>
      )
}

export default TodoAdd