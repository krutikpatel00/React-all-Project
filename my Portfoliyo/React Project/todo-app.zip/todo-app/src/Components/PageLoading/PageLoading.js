import React from 'react'
import { Spinner } from 'react-bootstrap'

const PageLoading = () => {
      return (
            <div className='position-fixed top-0 start-0 bg-white d-flex justify-content-center align-items-center w-100' style={{ height: '100vh' }}>
                  <Spinner animation="border" role="status">
                        <span className="visually-hidden">Loading...</span>
                  </Spinner>
            </div>
      )
}

export default PageLoading