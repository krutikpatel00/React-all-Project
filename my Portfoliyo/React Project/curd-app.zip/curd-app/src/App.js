import { Routes, Route } from "react-router-dom";
import UserdataAdd from "./Components/From/UserdataAdd";
import Header from "./Components/Header/Header";
import UserData from "./Components/UserData/UserData";
import 'bootstrap/dist/css/bootstrap.min.css';
import UpdatauserData from "./Components/UpdatauserData/UpdatauserData";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Header />}>
          <Route path="/" element={<UserdataAdd />} />
          <Route path="/userdata" element={<UserData />} />
          <Route path="/updatauser/:id" element={<UpdatauserData />} />
        </Route>
      </Routes>
    </>
  );
}

export default App;
