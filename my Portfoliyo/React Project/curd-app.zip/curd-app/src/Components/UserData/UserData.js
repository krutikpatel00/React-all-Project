import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Table, Container } from 'react-bootstrap';
import { UrlApi } from '../ReactApi';
import { Link } from 'react-router-dom'
import PageLoading from '../Loading/PageLoading';
import ErrorPage from '../ErrorPage/ErrorPage';

const UserData = () => {
      const [users, setUsers] = useState([])
      const [loading, setLoading] = useState(true)
      const [serach, setSerach] = useState('')
      const [currentPage, setCurrentPage] = useState(1);
      const [recordsPerPage, setRecordsPerPage] = useState(2);
      const [btnPage, setBtnPage] = useState([])
      const [Error, setError] = useState(null)


      useEffect(() => {
            getUsers()
      }, [currentPage, recordsPerPage])

      const getUsers = () => {
            axios.get(`${UrlApi}/users`).then((res) => {

                  let data = res.data

                  const indexOfLastRecord = currentPage * recordsPerPage;
                  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;

                  const currentRecords = data.slice(indexOfFirstRecord,
                        indexOfLastRecord);

                  const nPages = Math.ceil(data.length / recordsPerPage)
                  const pageNumbers = [...Array(nPages + 1).keys()].slice(1);

                  setBtnPage(pageNumbers)
                  setUsers(currentRecords)
                  setLoading(false)

            }).catch((error) => {
                  setError(error);
                  console.log(error);
                  setLoading(false)
            })
      }

      const UserDelete = (id) => {
            axios.delete(`${UrlApi}/users/${id}`).then((res) => {
                  getUsers()

            }).catch((error) => {
                  setError(error.message);
            })
      }


      if (loading) {
            return <PageLoading />

      }

      if (Error) {
            return <ErrorPage error={Error}></ErrorPage>
      }
      return (
            <div className='mt-5'>
                  <Container>
                        <div className='d-flex justify-content-between align-items-center '>
                              <div>
                                    <h6>{`Show `}<input defaultValue={recordsPerPage} onChange={(e) => setRecordsPerPage(e.target.value)} type='number' min={1} max={10} />{` Entries `}</h6>
                              </div>
                              <div>
                                    <label htmlFor="" className='me-2'>Search</label>
                                    <input type="text" name='serach' onChange={(e) => setSerach(e.target.value)} />
                              </div>
                        </div>
                        <Table striped className='border my-2'>
                              <thead>
                                    <tr>
                                          <th>#</th>
                                          <th>images</th>
                                          <th>User Name</th>
                                          <th>Email</th>
                                          <th>Phone</th>
                                          <th>action</th>

                                    </tr>
                              </thead>
                              <tbody>
                                    {users.filter((user, index) => {
                                          if (serach !== '') {
                                                return user.userName.match(serach) || user.email.match(serach) || user.phone.match(serach)
                                          } else {
                                                return user
                                          }
                                    }).map((items, pos) => {
                                          return (
                                                <tr key={pos}>
                                                      <td>{currentPage * recordsPerPage - recordsPerPage + ++pos}</td>
                                                      <td><img src={items.images} width={'40px'} className='object-fit-cover ' height={'40px'} alt="" /></td>
                                                      <td>{items.userName}</td>
                                                      <td>{items.email}</td>
                                                      <td>{items.phone}</td>
                                                      <td>
                                                            <Link onClick={() => UserDelete(items.id)} className='text-decoration-none btn bg-danger-subtle mx-1'><i className="ri-delete-bin-6-fill" ></i></Link>
                                                            <Link to={`/updatauser/${items.id}`} className='text-decoration-none btn bg-primary-subtle'><i className="ri-edit-box-line"></i></Link>
                                                      </td>
                                                </tr>
                                          )
                                    })
                                    }
                              </tbody>
                        </Table>
                        <div className='d-flex justify-content-between align-items-center'>
                              <div>
                                    <span>{`Showing ${currentPage * recordsPerPage - recordsPerPage + 1} To ${currentPage * recordsPerPage - recordsPerPage + users.length} of ${currentPage * recordsPerPage - recordsPerPage + users.length} Enties`}</span>
                              </div>
                              {
                                    btnPage.length !== 0 ? <div>
                                          {currentPage !== btnPage[0] ? <button onClick={() => setCurrentPage(currentPage - 1)} className=' btn bg-dark-subtle'>Prevous</button> : ''}
                                          <button className='btn bg-primary-subtle mx-1'>{currentPage}</button>
                                          {
                                                currentPage !== btnPage.length ? <button button onClick={() => setCurrentPage(currentPage + 1)} className='btn bg-dark-subtle '>Next</button> : ''
                                          }
                                    </div> : ''
                              }
                        </div>
                  </Container >

            </div >
      )
}

export default UserData