import React, { useEffect, useState } from 'react'
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import axios from 'axios'
import { UrlApi } from '../ReactApi';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useParams } from 'react-router-dom';

const UpdatauserData = () => {
      const { id } = useParams()
      const [useData, setUsedata] = useState({})
      const [url, setUrl] = useState(false)
      const navigate = useNavigate()

      useEffect(() => {
            axios.get(`${UrlApi}/users/${id}`).then((res) => {
                  setUsedata(res.data)
            }).catch((error) => {
                  console.log(error);
            })
      }, [])

      const InputValueGet = (e) => {
            const name = e.target.name;
            const value = e.target.value;
            const data = { ...useData, [name]: value }
            if (!url) {
                  if (name === 'images') {
                        data.images = e.target.files[0].name
                        console.log(e.target.files[0].name);
                  }
            }

            setUsedata(data)
      }

      const UserDataUpdata = (e) => {
            e.preventDefault()
            var numbers = /^[0-9]+$/;
            var paswd = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

            if (useData.userName === undefined) {
                  toast.error('UserName is Required')
            }
            else if (useData.userName.length <= 3) {
                  toast.error('3 Or More Character Required')
            }
            else if (useData.email === undefined) {
                  toast.error('Email is Required')
            }
            else if (!(useData.email.match(mailformat))) {
                  toast.error('Invalid Email Address')
            }
            else if (useData.password === undefined) {
                  toast.error('password  is Required')
            }
            else if (!(useData.password.match(paswd))) {
                  toast.error('[8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character]')
            }
            else if (useData.phone === undefined) {
                  toast.error('Phone is Required')
            }
            else if (!(useData.phone.match(numbers))) {
                  toast.error('Only Number Required')
            }
            else if (useData.images === undefined) {
                  toast.error('Image is Required')
            }
            else {
                  axios.put(`${UrlApi}/users/${id}`, useData).then((res) => {
                        console.log(res.data);
                        navigate('/userdata')
                  }).catch((error) => {
                        console.log(error);
                  })
                  toast.success(`Successfully Updataed`)
                  setUsedata({})
            }
      }
      return (
            <div>
                  <h2 className='text-center'>Users Details Add</h2>
                  <Container>
                        <Row>
                              <Col>
                                    <Form method='post' onSubmit={(e) => UserDataUpdata(e)}>
                                          <Form.Group className="mb-3" controlId="formGroupName">
                                                <Form.Label>User Name</Form.Label>
                                                <Form.Control type="text" name='userName' value={useData.userName ? useData.userName : ''} placeholder="Enter UserName" onChange={(e) => InputValueGet(e)} />

                                          </Form.Group>
                                          <Form.Group className="mb-3" controlId="formGroupEmail">
                                                <Form.Label>Email address</Form.Label>
                                                <Form.Control type="text" name='email' value={useData.email ? useData.email : ""} placeholder="Enter email" onChange={(e) => InputValueGet(e)} />

                                          </Form.Group>
                                          <Form.Group className="mb-3" controlId="formGroupPassword">
                                                <Form.Label>Password</Form.Label>
                                                <Form.Control type="text" name='password' value={useData.password ? useData.password : ''} placeholder="Password" onChange={(e) => InputValueGet(e)} />

                                          </Form.Group>
                                          <Form.Group className="mb-3" controlId="formGroupPhone">
                                                <Form.Label>Phone</Form.Label>
                                                <Form.Control type="text" name='phone' value={useData.phone ? useData.phone : ''} placeholder="0000000000" onChange={(e) => InputValueGet(e)} />

                                          </Form.Group>
                                          <Form.Group className="mb-3" controlId="formGroupImage">
                                                <Form.Label>Image / Url</Form.Label> <span onClick={() => setUrl(!url)}>({`Click ${url ? 'File' : 'Url'}`})</span>
                                                <Form.Control type={url ? "url" : 'file'} value={url ? useData.images ? useData.images : "" : ''} name='images' placeholder="Enter Image" onChange={(e) => InputValueGet(e)} accept=".jpg, .jpeg, .png" />

                                          </Form.Group>
                                          <Button type='submit' variant="outline-primary">Updata</Button>
                                    </Form>
                              </Col>
                        </Row>
                  </Container>
                  <ToastContainer />
            </div>
      )
}

export default UpdatauserData