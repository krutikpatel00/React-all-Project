import React from 'react'

const ErrorPage = ({ error }) => {

      return (
            <div className="container">
                  <div className="d-flex align-items-center w-100 text-center" style={{ height: '100vh' }}>
                        <div className="col">
                              <h4 className='text-danger'>{error.message}</h4>
                        </div>
                  </div>
            </div>
      )
}

export default ErrorPage